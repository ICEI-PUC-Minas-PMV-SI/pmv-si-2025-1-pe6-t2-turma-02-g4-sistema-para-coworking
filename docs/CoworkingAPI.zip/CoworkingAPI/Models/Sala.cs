using System.ComponentModel.DataAnnotations;

namespace CoworkingAPI.Models
{

    public class Sala
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public required string Nome { get; set; }

        [Required]
        public required int Capacidade { get; set; }

        public required string Recursos { get; set; }
    }
}