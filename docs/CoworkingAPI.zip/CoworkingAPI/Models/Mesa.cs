using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoworkingAPI.Models
{
    public class Mesa
    {
        public int Id { get; set; }

        [Required]
        public int Numero { get; set; }

        [ForeignKey("Sala")]
        public int SalaId { get; set; }

        public required Sala Sala { get; set; }
    }
}