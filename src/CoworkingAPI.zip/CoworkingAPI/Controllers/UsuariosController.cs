using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoworkingAPI.Data;
using CoworkingAPI.Models;
using CoworkingAPI.DTOs;
using CoworkingAPI.Services;


namespace CoworkingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly AuthService _authService;

        public UsuariosController(AppDbContext context, AuthService authService)
        {
            _context = context;
            _authService = authService;
        }

        // GET: api/usuarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Usuario>>> GetUsuarios()
        {
            return await _context.Usuarios.ToListAsync();
        }

        // GET: api/usuarios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Usuario>> GetUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return usuario;
        }

        // POST: api/usuarios
        [HttpPost]
        public async Task<ActionResult<Usuario>> PostUsuario(Usuario usuario)
        {
            // Verifica se já existe um usuário com o mesmo e-mail ou CPF
            bool usuarioExiste = await _context.Usuarios
                .AnyAsync(u => u.Email == usuario.Email || u.CPF == usuario.CPF);

            if (usuarioExiste)
            {
                return BadRequest("Já existe um usuário cadastrado com esse e-mail ou CPF.");
            }

            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUsuario), new { id = usuario.Id }, usuario);
        }

        // PUT: api/usuarios/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUsuario(int id, Usuario usuario)
        {
            if (id != usuario.Id)
            {
                return BadRequest();
            }

            _context.Entry(usuario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Usuarios.Any(e => e.Id == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // PUT: api/usuarios/perfil/5
        [HttpPut("perfil/{id}")]
        [Authorize]
        public async Task<IActionResult> AtualizarPerfil(int id, AtualizarPerfilDTO dto)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
                return NotFound();

            usuario.Nome = dto.Nome;
            usuario.Email = dto.Email;
            usuario.Telefone = dto.Telefone;
            usuario.CPF = dto.CPF;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // PUT: api/usuarios/senha/5
        [HttpPut("senha/{id}")]
        [Authorize]
        public async Task<IActionResult> AtualizarSenha(int id, AtualizarSenhaDTO dto)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
                return NotFound();

            if (!_authService.VerifyPassword(dto.SenhaAtual, usuario.SenhaHash))
                return BadRequest("Senha atual incorreta.");

            if (dto.NovaSenha != dto.ConfirmarNovaSenha)
                return BadRequest("Nova senha e confirmação não coincidem.");

            usuario.SenhaHash = _authService.HashPassword(dto.NovaSenha);

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/usuarios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }

            _context.Usuarios.Remove(usuario);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}