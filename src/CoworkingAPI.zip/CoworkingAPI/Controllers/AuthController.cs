using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using CoworkingAPI.Data;
using CoworkingAPI.Models;
using CoworkingAPI.Services;
using CoworkingAPI.DTOs;

namespace CoworkingAPI.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly AuthService _authService;

        public AuthController(AppDbContext context, AuthService authService)
        {
            _context = context;
            _authService = authService;
        }

        // Endpoint para registro de usuários
        [HttpPost("register")]
        public async Task<IActionResult> Register(Usuario usuario)
        {
            // Verifica se o e-mail já está cadastrado
            if (_context.Usuarios.Any(u => u.Email == usuario.Email))
                return BadRequest("E-mail já cadastrado.");

            // Criptografa a senha
            usuario.SenhaHash = _authService.HashPassword(usuario.SenhaHash);

            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuário registrado com sucesso!" });
        }

        // Endpoint para login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO usuarioLogin)
        {
            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Email == usuarioLogin.Email);

            if (usuario == null || !_authService.VerifyPassword(usuarioLogin.Senha, usuario.SenhaHash))
                return Unauthorized("Credenciais inválidas.");

            var token = _authService.GenerateJwtToken(usuario);
            return Ok(new { token });
        }
    }
}
