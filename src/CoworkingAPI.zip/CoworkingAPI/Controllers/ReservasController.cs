using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CoworkingAPI.Data;
using CoworkingAPI.Models;
using CoworkingAPI.DTOs;

namespace CoworkingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class ReservasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ReservasController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/reservas
        [HttpGet]
        // [Authorize(Roles = "admin")]
        public async Task<ActionResult<IEnumerable<Reserva>>> GetReservas()
        {
            return await _context.Reservas
                .Include(r => r.Usuario)
                .Include(r => r.Sala)
                .Include(r => r.Mesa)
                .ToListAsync();
        }

        // GET: api/reservas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Reserva>> GetReserva(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);
            if (reserva == null) return NotFound();

            return reserva;
        }


        // POST: api/reservas
        [HttpPost]
        // [Authorize]
        public async Task<ActionResult<Reserva>> PostReserva(ReservaDTO reservaDTO)
        {
            // Obtém o ID do usuário autenticado
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            // Verifica se o userId é válido antes de converter para int
            if (string.IsNullOrEmpty(userId) || !int.TryParse(userId, out int usuarioId))
            {
                return Unauthorized("Usuário não autenticado ou ID inválido.");
            }

            // Busca o usuário autenticado no banco
            var usuario = await _context.Usuarios.FindAsync(usuarioId);
            if (usuario == null)
            {
                return Unauthorized("Usuário não encontrado.");
            }

            // Busca a sala, se informada
            Sala? sala = null;
            if (reservaDTO.SalaId.HasValue)
            {
                sala = await _context.Salas.FindAsync(reservaDTO.SalaId.Value);
                if (sala == null)
                {
                    return BadRequest("Sala não encontrada.");
                }
            }

            // Busca a mesa, se informada
            Mesa? mesa = null;
            if (reservaDTO.MesaId.HasValue)
            {
                mesa = await _context.Mesas.FindAsync(reservaDTO.MesaId.Value);
                if (mesa == null)
                {
                    return BadRequest("Mesa não encontrada.");
                }
            }

            // Verifica se a reserva é válida (deve ter uma SalaId OU uma MesaId)
            if (sala == null && mesa == null)
            {
                return BadRequest("A reserva deve estar vinculada a uma sala ou a uma mesa.");
            }

            // Verifica se já existe uma reserva para a mesma sala ou mesa na mesma data/hora
            bool reservaExiste = await _context.Reservas.AnyAsync(r =>
                r.DataHora == reservaDTO.DataHora &&
                (r.SalaId == reservaDTO.SalaId || r.MesaId == reservaDTO.MesaId));

            if (reservaExiste)
            {
                return BadRequest("Já existe uma reserva para essa sala ou mesa nesse horário.");
            }

            // Verifica se a reserva é para uma data no passado
            if (reservaDTO.DataHora < DateTime.UtcNow)
            {
                return BadRequest("Não é possível criar reservas para datas passadas.");
            }

            // Criar objeto de reserva
            var reserva = new Reserva
            {
                UsuarioId = usuarioId,
                Usuario = usuario,
                SalaId = reservaDTO.SalaId,
                Sala = sala!,
                MesaId = reservaDTO.MesaId,
                Mesa = mesa!,
                DataHora = reservaDTO.DataHora,
                Status = "Confirmada"
            };

            // Salvar reserva no banco
            _context.Reservas.Add(reserva);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetReserva), new { id = reserva.Id }, new
            {
                message = $"Sua reserva foi confirmada! ID: {reserva.Id}",
            });
        }



        // PUT: api/reservas/5
        [HttpPut("{id}")]
        // [Authorize]
        public async Task<IActionResult> PutReserva(int id, Reserva reserva)
        {
            var reservaExistente = await _context.Reservas.FindAsync(id);

            if (reservaExistente == null)
            {
                return NotFound();
            }

            // Obtém o ID do usuário autenticado
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (reservaExistente.UsuarioId.ToString() != userId && !User.IsInRole("admin"))
            {
                return Forbid();  // 403 Forbidden
            }

            _context.Entry(reservaExistente).CurrentValues.SetValues(reserva);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/reservas/5
        [HttpDelete("{id}")]
        // [Authorize]
        public async Task<IActionResult> DeleteReserva(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);

            if (reserva == null)
            {
                return NotFound();
            }

            // Obtém o ID do usuário autenticado
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (reserva.UsuarioId.ToString() != userId && !User.IsInRole("admin"))
            {
                return Forbid();  // 403 Forbidden
            }

            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}