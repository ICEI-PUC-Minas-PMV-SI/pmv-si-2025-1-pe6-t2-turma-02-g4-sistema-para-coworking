using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Threading.RateLimiting;
using CoworkingAPI.Data;
using CoworkingAPI.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
builder.Services.AddControllers();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configuração JWT
var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"] ?? throw new ArgumentNullException("Jwt:Key", "A chave JWT não pode ser nula."));

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(key)
        };
    });


// PROTEÇÕES ADICIONAIS > falta adicionar ASP.NET Rate Limiting
// Proteção contra Brute Force no login
builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
        RateLimitPartition.GetFixedWindowLimiter("global", partition =>
            new FixedWindowRateLimiterOptions
            {
                PermitLimit = 5,  // Máximo de 5 tentativas
                Window = TimeSpan.FromMinutes(1), // Por 1 minuto
                QueueLimit = 0 // Bloqueia a partir de 5 tentativas
            }));
});


builder.Services.AddScoped<AuthService>(); // Adiciona o serviço de autenticação
builder.Services.AddAuthorization();
builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
// http://localhost:5289/swagger

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection(); // Redireciona HTTP para HTTPS (se necessário)
app.UseRateLimiter(); // Aplica Rate Limiting para proteção
app.UseAuthentication(); // 🔹 Adiciona autenticação JWT
app.UseAuthorization();
app.MapControllers();
app.Run();
