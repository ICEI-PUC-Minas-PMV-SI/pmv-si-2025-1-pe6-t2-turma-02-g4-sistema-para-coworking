using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Threading.RateLimiting;
using CoworkingAPI.Data;
using CoworkingAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// Configuração do arquivo de configurações
builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

// Adiciona serviços ao container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configuração do banco de dados
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configuração CORS (Permitir frontend React)
builder.Services.AddCors(options =>
{
    options.AddPolicy("LiberarFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:3000") // URL do frontend
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials(); // Para JWT/cookies
    });
});

// Configuração JWT
var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"] ?? throw new ArgumentNullException("Jwt:Key", "A chave JWT não pode ser nula."));

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
        };
    });

// Configuração de Rate Limiting (proteção contra brute force)
builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
        RateLimitPartition.GetFixedWindowLimiter("global", partition =>
            new FixedWindowRateLimiterOptions
            {
                PermitLimit = 5,  // Máximo de 5 requisições
                Window = TimeSpan.FromMinutes(1), // Por 1 minuto
                QueueLimit = 0 // Bloqueia após o limite
            }));
});

// Serviços personalizados
builder.Services.AddScoped<AuthService>();
builder.Services.AddAuthorization();

// Construção da aplicação
var app = builder.Build();

// Middlewares (ordem CRÍTICA)
app.UseCors("LiberarFrontend"); // Cors PRIMEIRO

// Configuração do Swagger apenas em desenvolvimento
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Redirecionamento HTTPS (apenas em produção)
if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();
}

app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();