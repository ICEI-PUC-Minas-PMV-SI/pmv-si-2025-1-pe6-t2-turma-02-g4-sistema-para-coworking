namespace CoworkingAPI.DTOs
{
    public class AtualizarPerfilDTO
    {
        public required string Nome { get; set; }
        public required string Email { get; set; }
        public string? Telefone { get; set; }
        public required string CPF { get; set; }
    }
}
