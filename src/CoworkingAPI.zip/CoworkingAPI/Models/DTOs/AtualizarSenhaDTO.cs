namespace CoworkingAPI.DTOs
{
    public class AtualizarSenhaDTO
    {
        public required string SenhaAtual { get; set; }
        public required string NovaSenha { get; set; }
        public required string ConfirmarNovaSenha { get; set; }
    }
}
