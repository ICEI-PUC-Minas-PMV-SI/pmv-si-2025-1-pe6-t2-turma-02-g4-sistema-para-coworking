namespace CoworkingAPI.DTOs
{
    public class ReservaDTO
    {
        /// <summary>
        /// ID da Sala para a reserva (opcional)
        /// </summary>
        public int? SalaId { get; set; }

        /// <summary>
        /// ID da Mesa para a reserva (opcional)
        /// </summary>
        public int? MesaId { get; set; }

        /// <summary>
        /// Data e horário da reserva
        /// </summary>
        public DateTime DataHora { get; set; }

        /// <summary>
        /// Status da reserva (opcional). Se não informado, será "Pendente".
        /// </summary>
        public string? Status { get; set; } = null; // Opcional (null por padrão)
    }
}