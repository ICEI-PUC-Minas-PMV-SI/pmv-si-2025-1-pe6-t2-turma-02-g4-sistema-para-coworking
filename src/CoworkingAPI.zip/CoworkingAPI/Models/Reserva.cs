using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoworkingAPI.Models
{

    public class Reserva
    {
        public int Id { get; set; }

        [ForeignKey("Usuario")]
        public int UsuarioId { get; set; }
        public Usuario? Usuario { get; set; }

        [ForeignKey("Sala")]
        public int? SalaId { get; set; }
        public Sala? Sala { get; set; }

        [ForeignKey("Mesa")]
        public int? MesaId { get; set; }
        public Mesa? Mesa { get; set; }

        [Required]
        public DateTime DataHora { get; set; }

        [Required]
        [MaxLength(20)]
        public string Status { get; set; } = "Pendente";
    }
}