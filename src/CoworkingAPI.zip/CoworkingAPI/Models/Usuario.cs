using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CoworkingAPI.Models
{

    public class Usuario
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório.")]
        [MaxLength(100, ErrorMessage = "O nome pode ter no máximo 100 caracteres.")]
        public required string Nome { get; set; }

        [Required(ErrorMessage = "O e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "Formato de e-mail inválido.")]
        public required string Email { get; set; }

        [MaxLength(20, ErrorMessage = "O telefone pode ter no máximo 20 caracteres.")]
        public string? Telefone { get; set; }  // Pode ser nulo

        [Required(ErrorMessage = "O CPF é obrigatório.")]
        [MaxLength(14, ErrorMessage = "O CPF deve ter no máximo 14 caracteres.")]
        public required string CPF { get; set; }

        [Required(ErrorMessage = "A senha é obrigatória.")]
        public required string SenhaHash { get; set; }

        [Required]
        [MaxLength(20)]
        public string Role { get; set; } = "usuario";
    }
}